﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzzProject
{
    public class FizzBuzz
    {
        public string Go(int number)
        {
            var result = "";
            if (number % 3 == 0 )
            {
                result += "Fizz";
            }
            if (number % 5 == 0)
            {
                result += "Buzz";
            }
            if (String.IsNullOrEmpty(result))
            {
                result += number;
            }
            return result;
        }
    }
}
