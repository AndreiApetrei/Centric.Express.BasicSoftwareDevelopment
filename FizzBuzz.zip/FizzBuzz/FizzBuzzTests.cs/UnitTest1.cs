﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FizzBuzzProject;

namespace FizzBuzzTests.cs
{
    [TestClass]
    public class UnitTest1
    {
        private readonly FizzBuzz fizzBuzz = new FizzBuzz();

        [TestMethod]
        public void When_InputIs1_Then_OutputShouldBe1()
        {
            // Act
            var result = fizzBuzz.Go(1);

            // Assert
            Assert.AreEqual("1", result);
        }

        [TestMethod]
        public void When_InputIs2_Then_OutputShouldBe2()
        {
            // Act
            var result = fizzBuzz.Go(2);

            // Assert
            Assert.AreEqual("2", result);
        }

        [TestMethod]
        public void When_InputIsMultipleOf3_Then_OutputShouldBeFizz()
        {
            // Act
            var result = fizzBuzz.Go(3);

            // Assert
            Assert.AreEqual("Fizz", result);
        }
        [TestMethod]
        public void When_InputIsMultipleOf5_Then_OutputShouldBeBuzz()
        {
            // Act
            var result = fizzBuzz.Go(5);

            // Assert
            Assert.AreEqual("Buzz", result);
        }

        [TestMethod]
        public void When_InputIsMultipleOf3And5_Then_OutputShouldBeFizzBuzz()
        {
            // Act
            var result = fizzBuzz.Go(15);

            // Assert
            Assert.AreEqual("FizzBuzz", result);
        }
    }
}
